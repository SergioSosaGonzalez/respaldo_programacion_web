<?php

	define('SERVER', 'localhost');
	define('DBUSER', 'root');//
	define('DBPASS', '1234');//
	define('DBNAME', 'cecyte2');//
	